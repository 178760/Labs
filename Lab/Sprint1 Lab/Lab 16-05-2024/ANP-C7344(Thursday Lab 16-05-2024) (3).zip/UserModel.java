package com.companyname.springbootcrudrest.model;

import java.util.Date;

import jakarta.persistence.*; // Import JPA annotations

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name = "users")
@EntityListeners(AuditingEntityListener.class) // Enable auditing for this entity
public class User {

    private long id; // User ID
    private String firstName; // User's first name
    private String lastName; // User's last name
    private String emailId; // User's email address
    private Date createdAt; // Timestamp for creation
    private String createdBy; // User who created this record
    private Date updatedAt; // Timestamp for last update
    private String updatedby; // User who last updated this record
	
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
	
    @Column(name = "first_name", nullable = false)
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
	
    @Column(name = "last_name", nullable = false)
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
	
    @Column(name = "email_address", nullable = false)
    public String getEmailId() {
        return emailId;
    }
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }
	
    @Column(name = "created_at", nullable = false)
    @CreatedDate // Auto-populated creation timestamp
    @Temporal(TemporalType.TIMESTAMP) // Specify temporal type for the date
    public Date getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
	
    @Column(name = "created_by", nullable = false)
    @CreatedBy // Auto-populated creator
    public String getCreatedBy() {
        return createdBy;
    }
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
	
    @Column(name = "updated_at", nullable = false)
    @LastModifiedDate // Auto-populated last update timestamp
    @Temporal(TemporalType.TIMESTAMP) // Specify temporal type for the date
    public Date getUpdatedAt() {
        return updatedAt;
    }
    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }
	
    @Column(name = "updated_by", nullable = false)
    @LastModifiedBy // Auto-populated last updater
    public String getUpdatedby() {
        return updatedby;
    }
    public void setUpdatedby(String updatedby) {
        this.updatedby = updatedby;
    }
}
