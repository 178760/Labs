package com.companyname.springbootcrudrest.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.NOT_FOUND) // Indicates the HTTP status code to be returned
public class ResourceNotFoundException extends Exception {

    private static final long serialVersionUID = 1L;

    // Constructor to initialize ResourceNotFoundException with a custom message
    public ResourceNotFoundException(String message) {
        super(message);
    }
}
